import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import web3 from "../web3";

function Login() {
    const [account, setAccount] = useState("");
    const navigate = useNavigate();

    const connectWallet = async () => {
        try {
            const accounts = await web3.eth.requestAccounts();
            setAccount(accounts[0]);
            navigate("/dashboard");
        } catch (error) {
            console.error("MetaMask connection failed:", error);
        }
    };

    return (
        <div>
            <h1>Online Auction Platform</h1>
            {!account ? (
                <button onClick={connectWallet}>Connect MetaMask</button>
            ) : (
                <p>Connected: {account}</p>
            )}
        </div>
    );
}

export default Login;
