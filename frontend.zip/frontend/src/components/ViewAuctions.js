import React, { useEffect, useState } from "react";
import web3 from "../web3";
import auctionContract from "../contracts/AuctionABI.json";

function ViewAuctions() {
    const [auctions, setAuctions] = useState([]);

    useEffect(() => {
        const fetchAuctions = async () => {
            const auctionInstance = new web3.eth.Contract(
                auctionContract.abi,
                "YOUR_SMART_CONTRACT_ADDRESS"
            );
            const data = await auctionInstance.methods.getAuctions().call();
            setAuctions(data);
        };

        fetchAuctions();
    }, []);

    const placeBid = async (auctionId, bidAmount) => {
        const auctionInstance = new web3.eth.Contract(
            auctionContract.abi,
            "YOUR_SMART_CONTRACT_ADDRESS"
        );
        try {
            const accounts = await web3.eth.getAccounts();
            await auctionInstance.methods
                .bid(auctionId)
                .send({ from: accounts[0], value: web3.utils.toWei(bidAmount, "ether") });
            alert("Bid placed successfully!");
        } catch (error) {
            console.error("Error placing bid:", error);
        }
    };

    return (
        <div>
            <h1>Active Auctions</h1>
            {auctions.map((auction, index) => (
                <div key={index}>
                    <h3>{auction.title}</h3>
                    <p>Starting Price: {web3.utils.fromWei(auction.price, "ether")} ETH</p>
                    <p>End Time: {new Date(auction.endTime * 1000).toString()}</p>
                    <button
                        onClick={() =>
                            placeBid(auction.id, prompt("Enter your bid in ETH:"))
                        }
                    >
                        Place Bid
                    </button>
                </div>
            ))}
        </div>
    );
}

export default ViewAuctions;
