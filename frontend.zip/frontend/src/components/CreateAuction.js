import React, { useState } from "react";
import web3 from "../web3";
import auctionContract from "../contracts/AuctionABI.json";

function CreateAuction() {
    const [title, setTitle] = useState("");
    const [price, setPrice] = useState("");
    const [endTime, setEndTime] = useState("");

    const handleCreateAuction = async (e) => {
        e.preventDefault();
        const auctionInstance = new web3.eth.Contract(
            auctionContract.abi,
            "YOUR_SMART_CONTRACT_ADDRESS"
        );

        try {
            const accounts = await web3.eth.getAccounts();
            await auctionInstance.methods
                .createAuction(title, web3.utils.toWei(price, "ether"), endTime)
                .send({ from: accounts[0] });
            alert("Auction created successfully!");
        } catch (error) {
            console.error("Error creating auction:", error);
        }
    };

    return (
        <div>
            <h1>Create Auction</h1>
            <form onSubmit={handleCreateAuction}>
                <input
                    type="text"
                    placeholder="Auction Title"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    required
                />
                <input
                    type="text"
                    placeholder="Starting Price (ETH)"
                    value={price}
                    onChange={(e) => setPrice(e.target.value)}
                    required
                />
                <input
                    type="datetime-local"
                    value={endTime}
                    onChange={(e) => setEndTime(e.target.value)}
                    required
                />
                <button type="submit">Create Auction</button>
            </form>
        </div>
    );
}

export default CreateAuction;
