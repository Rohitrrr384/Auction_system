import React from "react";
import { Link } from "react-router-dom";

function Dashboard() {
    return (
        <div>
            <h1>Auction Dashboard</h1>
            <ul>
                <li>
                    <Link to="/create-auction">Create Auction</Link>
                </li>
                <li>
                    <Link to="/view-auctions">View Auctions</Link>
                </li>
            </ul>
        </div>
    );
}

export default Dashboard;
