import React, { useState, useEffect } from "react";
import auction from "../auction";

function Auctions() {
    const [auctions, setAuctions] = useState([]);

    useEffect(() => {
        const fetchAuctions = async () => {
            const count = await auction.methods.auctionCount().call();
            const items = [];
            for (let i = 1; i <= count; i++) {
                const item = await auction.methods.getAuctionDetails(i).call();
                items.push(item);
            }
            setAuctions(items);
        };
        fetchAuctions();
    }, []);

    const placeBid = async (auctionId, amount) => {
        const accounts = await window.ethereum.request({ method: "eth_requestAccounts" });
        await auction.methods.bid(auctionId).send({ from: accounts[0], value: amount });
        alert("Bid placed!");
    };

    return (
        <div>
            <h2>Active Auctions</h2>
            {auctions.map((a) => (
                <div key={a[0]}>
                    <h3>{a[1]}</h3>
                    <p>Start Price: {a[2]}</p>
                    <p>Highest Bid: {a[3]}</p>
                    <button onClick={() => placeBid(a[0], a[2] * 2)}>Bid</button>
                </div>
            ))}
        </div>
    );
}

export default Auctions;
