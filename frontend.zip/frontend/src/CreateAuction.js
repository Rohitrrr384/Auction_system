import React, { useState } from "react";
import auction from "../auction";

function CreateAuction() {
    const [name, setName] = useState("");
    const [price, setPrice] = useState(0);
    const [duration, setDuration] = useState(0);

    const createAuction = async () => {
        const accounts = await window.ethereum.request({ method: "eth_requestAccounts" });
        await auction.methods.createAuction(name, price, duration).send({ from: accounts[0] });
        alert("Auction Created!");
    };

    return (
        <div>
            <h2>Create Auction</h2>
            <input placeholder="Auction Name" onChange={(e) => setName(e.target.value)} />
            <input placeholder="Start Price (in wei)" onChange={(e) => setPrice(e.target.value)} />
            <input placeholder="Duration (in seconds)" onChange={(e) => setDuration(e.target.value)} />
            <button onClick={createAuction}>Create</button>
        </div>
    );
}

export default CreateAuction;
