import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Login from "./components/Login";
import Dashboard from "./components/Dashboard";
import CreateAuction from "./components/CreateAuction";
import ViewAuctions from "./components/ViewAuctions";

function App() {
    return (
        <Router>
            <Routes>
                <Route path="/" element={<Login />} />
                <Route path="/dashboard" element={<Dashboard />} />
                <Route path="/create-auction" element={<CreateAuction />} />
                <Route path="/view-auctions" element={<ViewAuctions />} />
            </Routes>
        </Router>
    );
}

export default App;
