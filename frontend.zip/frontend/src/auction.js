// client/src/auction.js
import web3 from "./web3";
import Auction from "./abis/Auction.json";

const contractAddress = "0x1e7E52b2CD4A661893E7075e412bA0fFCC25d72d"; // Replace with contract address
const auction = new web3.eth.Contract(Auction.abi, contractAddress);

export default auction;
